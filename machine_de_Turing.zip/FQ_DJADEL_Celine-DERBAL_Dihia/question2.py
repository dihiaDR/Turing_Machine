from turing_machine import *;

def test():
    program = open('ADD_a.txt').read()
    tm = TuringMachine(program, 1, '0101')

    tm.pas_calcul()
    tm.afficher(1)
