import question1;
import question2;
import question3_4;
import sys;

if __name__ == '__main__':
    fonction = sys.argv[1]
    if fonction == 'question1':
       question1.test()
    if fonction == 'question2':
        question2.test()
    if fonction == 'question3_4':
        question3_4.test()