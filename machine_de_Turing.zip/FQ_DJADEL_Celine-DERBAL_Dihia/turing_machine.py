from tape import*

class TuringMachine(object):
    init_state = "qinit"
    final_state = "F"
    alphabet = ["0","1"]
    alphabet_travail = ["0","1","_"]

    def __init__(self, program, k, word):
        self.current_state = TuringMachine.init_state
        self.tape_list = [Tape(word) if i == 0 else Tape(("_")*len(word)) for i in range(k)]
        self.program = program

    def afficher(self,n_stage):
        '''
        permet d'afficher la configuration de la MT
        '''
        print('############')
        print('Steps Counter : {}'.format(n_stage))
        print('Current State : {}'.format(self.current_state))
        for i in range(len(self.tape_list)):
            print('Tape Index : {}'.format(self.tape_list[i].head_position))
            affichage = '|'.join(map(str, self.tape_list[i].word))
            padding_icons = len(self.tape_list[i].word)*2*'='
            print(padding_icons,'▼',padding_icons)
            print(affichage)
            print(padding_icons,'▲',padding_icons)
        print('############')

    def transition(self):
        '''
        permet de récuperer toutes les transitions à partir du fichier de description de la MT
        '''
        contenu = self.program
        list = []
        transitions = {}
        list += contenu.splitlines()
        for i in range(len(list)-1):
            if not i%2:
               transitions[list[i]] = list[i+1]

        return(transitions)

    def existe_calcul(self):
        '''
        retourne le calcul à executer
        '''
        transitions = self.transition()
        cle = self.current_state

        val_par_ruban = [self.tape_list[i].word[self.tape_list[i].head_position] for i in range(len(self.tape_list))]
        cle += ''.join(" "+val_par_ruban[i] for i in range(len(val_par_ruban)))

        if cle in transitions.keys():
            calcul = transitions[cle]

            return (True,calcul)
      
    def pas_calcul(self):
        '''
        fonction qui étant donnée une MT lui fait executer un pas de clacul
        '''
        etape_calcul = self.existe_calcul()[1].split(' ')

        for i in range(len(etape_calcul)):
            if i == 0:
                self.current_state = etape_calcul[i]
            elif 1 <= i <= (len(etape_calcul)-1)/2:
                self.tape_list[i-(len(self.tape_list))-1].modify(etape_calcul[i])
            else:
                self.tape_list[i-(len(self.tape_list))-1].deplacer(etape_calcul[i])

    def simulate_machine(self):
        '''
        permet de simuler l'execution de la machine pas à pas
        '''
        n_stage = 0
        self.afficher(0)
        while self.existe_calcul():
            self.pas_calcul()
            n_stage += 1
            self.afficher(n_stage)
       
    def resultat(self):
        '''
        permet de savoir si l'entrée a bien été acceptée ou rejetée
        '''
        if self.current_state == self.final_state:
            print("Accepté")
        else:
            print("Rejeté")