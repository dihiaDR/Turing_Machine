class Tape:
    def __init__(self, word):
        self.head_position = 0
        self.word = list(word)
    
    #Permet de modifier ce qu'il y'a écrit sur le ruban
    def modify(self, value):
        chaine = self.word
        chaine[self.head_position] = value
        self.word = chaine
    
    #Permet de se déplacer dans le ruban en fonction de l'instruction de déplacement donnée
    def deplacer(self,deplacement):
        if deplacement == ">":
            if self.head_position == len(self.word)-1:
                self.word.append('_')
            self.head_position += 1
        elif deplacement == "<":
            if self.head_position == 0:
                self.word.insert(0,'_')
            else:
                self.head_position -= 1
        elif deplacement == "-":
            pass
        else: 
            print("Syntax error")   


