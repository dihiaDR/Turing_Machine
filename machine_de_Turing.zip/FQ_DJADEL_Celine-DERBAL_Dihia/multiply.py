def multiply(x,y):
    '''
    permet de multiplier deux nombres en binaire x et y en utilisant la méthode égyptienne.
    '''
    result = 0
    while x>0:
        if x%2 == 1:
            #appelle la machine qui réalise l'addition
            result = ADD(result, y)
        x = x>>1
        y = y<<1
    return result